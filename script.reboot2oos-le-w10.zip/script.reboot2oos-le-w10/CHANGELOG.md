# CHANGELOG
0.3.5 Updated grub, adjustments for LibreELEC

0.3.0 Updated default.py - back up your old script as they can be used with this version - They WILL be overwritten with this update.

0.2.0 New reboot2oos.sh script, more robust now.
Fixed up readme and other files to remove all openelec references/instructions.